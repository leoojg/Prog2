
document.getElementById("cadastro").onsubmit = validaCadastro;

function validaCadastro(){
	var contErro = 0;

	// validação do campo nome
	var nome = document.getElementById("nome");
	var erro_nome = document.getElementById("msg-nome");
	if((nome.value == "") || (nome.value.indexOf(" ") == -1)){
		erro_nome.innerHTML = "Por favor digite o Nome completo";
		erro_nome.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_nome.style.display = "none";
	}

	// validação do campo apelido
	var apelido = document.getElementById("apelido");
	var erro_apelido = document.getElementById("msg-apelido");
	if((apelido.value == "")){
		erro_apelido.innerHTML = "Por favor digite o apelido";
		erro_apelido.style.display = 'block';
		contErro+=1;
	}else if(apelido.value.length < 3){
		erro_apelido.innerHTML = "O apelido deve possuir pelo menos 3 digitos";
		erro_apelido.style.display = 'block';
	}else{
		erro_apelido.style.display = "none";
	}

	// validação do campo email
	var email = document.getElementById("email");
	var erro_email = document.getElementById("msg-email");
	if((email.value == "") || (email.value.indexOf("@") == -1)){
		erro_email.innerHTML = "Por favor digite o E-mail";
		erro_email.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_email.style.display = 'none';
	}

	// validação do campo login
	var login = document.getElementById("login");
	var erro_login = document.getElementById("msg-login");
	if(login.value == ""){
		erro_login.innerHTML = "Por favor digite o login";
		erro_login.style.display = 'block';
		contErro+=1;
	}
	else if (login.value.length < 6){
		erro_login.innerHTML = "O Login deve possuir pelo menos 6 caracteres";
		erro_login.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_login.style.display = 'none';
	}

	// validação do campo senha
	var senha = document.getElementById("senha");
	var erro_senha = document.getElementById("msg-senha");
	if(senha.value == ""){
		erro_senha.innerHTML = "Por favor digite a Senha";
		erro_senha.style.display = 'block';
		contErro+=1;
	}
	else if (senha.value.length < 6){
		erro_senha.innerHTML = "A Senha deve possuir pelo menos 6 caracteres";
		erro_senha.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_senha.style.display = 'none';
	}

	// validação da repetição da senha
	var senha2 = document.getElementById("senha2");
	var erro_senha2 = document.getElementById("msg-senha2");
	if((senha2.value == "") || (senha.value != senha2.value)){
		erro_senha2.innerHTML = "A senha não confere";
		erro_senha2.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_senha2.style.display = 'none';
	}	
	if(contErro > 0)
		return false;
	else
		alert("Dados recebidos com sucesso"); // será removido posteriormente
}
