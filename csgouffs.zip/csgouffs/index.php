<?php
	include "includes/cabecalho.php";
?>
	<div class="container">
		<h2 class="titulo">Equipes</h2>
		<?php
		include "includes/conexao.php";
		include "includes/functions.php";
		$sql = "SELECT * FROM equipes order by nometime asc";
		$resultado = mysqli_query($conexao, $sql);
		if(mysqli_num_rows($resultado) == 0){
				?>
				<tr>
					<td colspan="4">Nenhuma equipe encontrada.</td>
				</tr>
				<?php	
			}
			else{
				while($equipe = mysqli_fetch_array($resultado)){
					?>				
					<div class="jogador">
						<figure>
							<img class="jogador_foto" src="img/equipes/<?=mostraImagem($equipe['imagem']);?>">
							
							<div class="jogador_info">
								<?php
									for($i = 1; $i <= 5; $i = $i +1)
										$id[] = $equipe['id'.$i];
									foreach ($id as $_i){
										$sql = "SELECT * FROM jogador WHERE id = '$_i'";
										$resultado2 = mysqli_query($conexao, $sql);
										$jogador = mysqli_fetch_array($resultado2);
										echo "<a id=\"steamid\" href=\"{$jogador['url']}\">{$jogador['apelido']}</a><br>";
									}
								$id = null;
								?>
							</div>
							<figcaption class="titulo"><?=$equipe['nometime']; ?></figcaption>
						</figure>
					</div>
					<?
				}
			}
		?>
	</div>
<?php
	include "includes/rodape.php";
?>