<?php
  include "includes/conexao.php";
  $login = $_POST["login"];
  $sql = "select id, apelido, nome, login, senha from jogador where login = '$login';";
  $resultado = mysqli_query($conexao, $sql);
  if(mysqli_num_rows($resultado) == 0){
    header("Location: login.php?erro=1");
  }else{
    $user = mysqli_fetch_array($resultado);
    $senha2 = md5($_POST["senha"]);
    if($user["senha"] == $senha2){
      session_start();
      $_SESSION['apelido'] = $user['apelido'];
			$_SESSION["login"] = $login;
      $_SESSION["nome"] = $user["nome"];
      $_SESSION["id"] = $user["id"];
			header("Location: index.php");
    }else{
      header("Location: login.php?erro=1");
    }
  }
 ?>
