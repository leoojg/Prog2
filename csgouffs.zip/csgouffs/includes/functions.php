<?php
function mostraImagem($nomeArquivo){
	if($nomeArquivo == 'NULL')
		return "default.jpg";
	else
		return $nomeArquivo;
}
?>