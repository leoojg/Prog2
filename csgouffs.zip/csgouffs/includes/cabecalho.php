<?php
@session_start();
?>
<!doctype html>
<html lang="pt-br">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<title>UFFS CSGO</title>
	<link rel="stylesheet" type="text/css" href="css/csgo.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet"> 
</head>
<body>

	<header>
		<h1>UFFS CSGO</h1>
		<?php
			if(isset($_SESSION["login"]) && isset($_SESSION["nome"])){
				$variavel = "Olá, ";
				$variavel.= $_SESSION["apelido"] ;
				$variavel.="! <a href=\"sair.php\">(Sair)</a>";
			}else{
				$variavel = "<a href=\"login.php\">Login</a>";
			}
		?>
		<p class="menu_login"><?=$variavel?>&nbsp;&nbsp;&nbsp;&nbsp;</p>
		<nav class="menu">
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="inscricoes.php">Inscrições</a></li>
				<li><a href="jogadores.php">Jogadores</a></li>
				<?php
				if(isset($_SESSION['login'])){
					?>
					<li><a href="minhaconta.php">Minha Conta</a></li>
					<?php
				}
				?>
			</ul>
		</nav>
	</header>