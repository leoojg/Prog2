<?php
	include "includes/cabecalho.php";
?>
	<div class="container">
		<form class="formulario">
		<fieldset>
			<legend>Jogue conosco</legend>
			<label>Nome:</label>
				<input type="text" name="nome_jogador" id="nome_jogador" size="40" required>
			<br>
			<label>Posição:</label>
				<label><input type="checkbox" name="pos_entry" id="pos_entry" value="entry">Entry-Fragger</label>
				<label><input type="checkbox" name="pos_play" id="pos_play" value="play">Playmaker</label>
				<label><input type="checkbox" name="pos_sniper" id="pos_sniper" value="sniper">Sniper</label>
				<label><input type="checkbox" name="pos_lurker" id="pos_lurker" value="lurker">Lurker</label>
			<br>
			<label>Skillgroup:</label>
				<input type="text" name="skill_jogador" id="skill_jogador" size="25">		
			<br>
			<input type="submit" value="Cadastrar-se">
			<input type="reset" value="Reset">
		</fieldset>
	</form>
	<form class="formulario">
		<fieldset>
			<legend>Cadastre seu time</legend>
			<label>Nome do time:</label>
				<input type="text" name="nome_time" id="nome_time" required>
			<br><br>
			<label>Coach:</label>
				<input type="text" name="nome_coach" id="nome_coach" size="40">
			<br><br>
			<label>Nome dos jogadores:</label><br>
				<br><label>Jogador 1:</label>
				<input type="text" name="nome_jogador1" id="nome_jogador1" size="40" required>
				<br><label>Jogador 2:</label>
				<input type="text" name="nome_jogador2" id="nome_jogador2" size="40" required>
				<br><label>Jogador 3:</label>
				<input type="text" name="nome_jogador3" id="nome_jogador3" size="40" required>
				<br><label>Jogador 4:</label>
				<input type="text" name="nome_jogador4" id="nome_jogador4" size="40" required>
				<br><label>Jogador 5:</label>
				<input type="text" name="nome_jogador5" id="nome_jogador5" size="40" required>
			<br>
			<label>Marque o horário preferencial para jogo:</label>
				<label><input type="radio" name="horario" id="horario_m" value="Matutino">Matutino</label>
				<label><input type="radio" name="horario" id="horario_v" value="Vespertino">Vespertino</label>
				<label><input type="radio" name="horario" id="horario_n" value="Noturno">Noturno</label>
			<br>
			<label>Selecione os dias de jogos:</label>
				<label><input type="checkbox" name="dia" id="dia_dom" value="Domingo">Domingo</label>
				<label><input type="checkbox" name="dia" id="dia_seg" value="Segunda">Segunda</label> 
				<label><input type="checkbox" name="dia" id="dia_ter" value="Terça">Terça</label>
				<label><input type="checkbox" name="dia" id="dia_qua" value="Quarta">Quarta</label>
				<label><input type="checkbox" name="dia" id="dia_qui" value="Quinta">Quinta</label>
				<label><input type="checkbox" name="dia" id="dia_sex" value="Sexta">Sexta</label>
				<label><input type="checkbox" name="dia" id="dia_sab" value="Sabado">Sabado</label>
			<br>
			<input type="submit" value="Cadastrar Time!">
			<input type="reset" value="Reset">
		</fieldset>
	</form>
	</div>
<?php
	include "includes/rodape.php";
?>