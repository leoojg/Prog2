<footer>
		<p>UFFS CSGO - Chapecó/SC</p>
	</footer>

</body>
</html>