<?php
	include "includes/cabecalho.php";
?>
	<div class="container">
		<h2 class="titulo">Jogadores</h2>
		<?php
		include "includes/conexao.php";
		include "includes/functions.php";
		$sql = "SELECT * FROM jogador order by nome asc";
		$resultado = mysqli_query($conexao, $sql);
		if( mysqli_num_rows($resultado) == 0){
				?>
				<tr>
					<td colspan="4">Nenhum jogador encontrado.</td>
				</tr>
				<?php	
			}
			else{
				while($jogador= mysqli_fetch_array($resultado)){
					?>				
					<div class="jogador">
						<figure>
							<img class="jogador_foto" src="img/jogadores/<?=mostraImagem($jogador['imagem']);?>">		
							<div class="jogador_info">
								<p><?=$jogador['nome']; ?></p>
								<p><?=$jogador['apelido']; ?></p>
								<a id="steamid" href="<?=$jogador['url'];?>">STEAM</a>

							</div>
						</figure>
					</div>
					<?
				} // while
			} // else
			?>
	</div>
<?php
	include "includes/rodape.php";
?>