<?php
$erros=array();
	if(isset($_POST['cadastrar'])){
		$nome = trim(addslashes($_POST['nome']));
		$apelido = trim(addslashes($_POST['apelido']));
		$steamid = isset($_POST['steamid']) ? trim(addslashes($_POST['steamid'])) : 'null';
		$imagem = empty($_FILES['arquivo']['name']) ? 'NULL' : "'{$_FILES['arquivo']['name']}'"; 
		$email = trim(addslashes($_POST['email']));
		$login = trim(addslashes($_POST['login']));
		$senha1 = trim(addslashes($_POST['senha']));
		$senha2 = trim(addslashes($_POST['senha2']));
		
		if (empty($nome) || !strstr($nome," "))
			$erros[] = "Digite seu nome completo.";
		if (empty($apelido))
			$erros[] = "Digite seu nickname.";
		else if(strlen($apelido) < 3)
			$erros[] = "O apelido deve possuir pelo menos 3 digitos.";
		if (empty($nome) || !strstr($nome," "))
			$erros[] = "Digite seu nome completo";
		if(empty($email) || !(filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)))
           $erros[] = "Digite um email válido.";	

		$regex = "/^[a-z\d_]{6,20}$/i";
		if(empty($login) || !preg_match($regex, $login))
			$erros[] = "O login deve possuir entre 6 e 20 caracteres (letras, números e underline).";
		
		if(strlen($senha1) < 6)
			$erros[] = "A senha deve ter no mínimo 6 caracteres.";
		else{
			if($senha1 != $senha2)
				$erros[] = "As senhas não conferem.";
		}
		include "includes/conexao.php";
		$sql = "SELECT * FROM jogador WHERE login = '$login';";
		$resultado = mysqli_query($conexao, $sql);
		if(mysqli_num_rows($resultado) > 0)
			$erros[] = "Este Login já existe.";
		
		if($imagem <> 'NULL' && count($erros) == 0){
		 	$imagem = $login;
			$destino = "img/jogadores/".$login;
			if(!move_uploaded_file($_FILES['arquivo']['tmp_name'], $destino)){
				$erros[] = "Falha no upload do arquivo";
			}
		}
		if(count($erros) == 0){
			$nova = md5($senha1);	
			$sql = "INSERT INTO jogador (nome, apelido, url, imagem, email, login, senha) VALUES ('$nome', '$apelido', '$steamid', '$imagem', '$email', '$login', '$nova')";
			$resultado = mysqli_query($conexao, $sql);
			if($resultado){
				$mensagem = "O jogador <strong>$nome</strong> foi inserido com sucesso";
			}
			else{
				$mensagem = "Erro. O jogador não pôde ser cadastrado.";
				$mensagem .= mysqli_error($conexao); // para debug
			}
		}
	}

include "includes/cabecalho.php";
?>

<div class="container">
	<h2 class="titulo">Cadastre-se</h2>
	<?php 
		// caso houver, exibe os erros
		if(isset($erros) and count($erros) > 0){
			echo "<ul>";
			foreach ($erros as $erro) {
				echo "<li style='color:red'>$erro</li>";
			}
			echo "</ul>";
		}
	?>
	<?php 
		if(!(isset($_POST['cadastrar'])) || count($erros)!=0){
	?>
	<div class="container">
		<form action="" method="post" id="cadastro" onsubmit="validaCadastro()" enctype="multipart/form-data">
		    <div class="form-item">
			    <label for="nome" class="label-alinhado">Nome:</label>
			    <input type="text" id="nome" name="nome" size="50" placeholder="Nome completo">
			    <span class="msg-erro" id="msg-nome"></span>
			</div>
			<div class="form-item">
			    <label for="apelido" class="label-alinhado">Nickname:</label>
				<input type="text" id="apelido" name="apelido" size="20" placeholder="Apelido">
			    <span class="msg-erro" id="msg-apelido"></span>
			</div>
			<div class="form-item">
				<label for="steamid" class="label-alinhado">Steam url:</label>
				<input type="text" id="steamid" name="steamid" size="35" placeholder="https://steamcommunity.com/id/steamid/">
		    </div>
			<div class="form-item">
				<label for="arquivo" class="label-alinhado">Envie a imagem da sua Steam:</label>
				<input type="file" name="arquivo" id="arquivo">
			</div>
		    <div class="form-item">
			    <label for="email" class="label-alinhado">E-mail:</label>
			    <input type="email" id="email" name="email" placeholder="exemple@email.com" size="50">
			    <span class="msg-erro" id="msg-email"></span>
		    </div>					    				    
		    <div class="form-item">
			    <label for="login" class="label-alinhado">Login:</label>
			    <input type="text" id="login" name="login" placeholder="Mínimo 6 caracteres" >
			    <span class="msg-erro" id="msg-login"></span>
		    </div>				    
		    <div class="form-item">
			    <label for="senha" class="label-alinhado">Senha:</label>
			    <input type="password" id="senha" name="senha" placeholder="Mínimo 6 caracteres" >
			    <span class="msg-erro" id="msg-senha"></span>
		    </div>
		    <div class="form-item">
			    <label for="senha2" class="label-alinhado">Repita a Senha:</label>
			    <input type="password" id="senha2" name="senha2" placeholder="Mínimo 6 caracteres">
			    <span class="msg-erro" id="msg-senha2"></span>
		    </div> 			    
		    <div class="form-item">
		    <label class="label-alinhado"></label>
		    <input type="submit" id="botao" value="Confirmar" name="cadastrar">
		    </div>
		</form>
	</div>		
	<?php 
		}else{
			echo "<p>Jogador <strong>$apelido</strong> cadastrado com sucesso!</p>";
		}
	?>
</div>
<footer>
		<p>UFFS CSGO - Chapecó/SC</p>
		<script src="cadastro.js"></script>
</footer>
</body>
</html>