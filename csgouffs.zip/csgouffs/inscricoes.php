<?php
	@session_start();
	include "includes/conexao.php";
	$erros = array();
	if(isset($_POST['cadastrar'])){
		$usuario = $_SESSION['login'];
		$nome_time = trim(addslashes($_POST['nome_time']));
		$imagem = empty($_FILES['arquivo']['name']) ? 'NULL' : "'{$_FILES['arquivo']['name']}'"; 
		$jogadores[] = trim(addslashes($_POST['nome_jogador1']));
		$jogadores[] = trim(addslashes($_POST['nome_jogador2']));
		$jogadores[] = trim(addslashes($_POST['nome_jogador3']));
		$jogadores[] = trim(addslashes($_POST['nome_jogador4']));
		$jogadores[] = trim(addslashes($_POST['nome_jogador5']));

		if($nome_time == "")
			$$erros[] = "O nome do time não pode ser em branco.";
		else if(strlen($nome_time) < 3)
			$erros[] = "O nome do time precisa ter mais que tres letras.";
		for($i = 0; $i < 5; $i = $i + 1){
			$sql = "SELECT * FROM jogador where apelido = '$jogadores[$i]'";
			$resultado = mysqli_query($conexao, $sql);
			if(mysqli_num_rows($resultado) == 0)
				$erros[] = "O jogador $jogadores[$i] não existe.";
			while($aux = mysqli_fetch_array($resultado))
				$id[] = $aux['id'];
		}
		
		$sql = "SELECT * FROM equipes WHERE nometime = '$nome_time';";
		$resultado = mysqli_query($conexao, $sql);
		if(mysqli_num_rows($resultado) > 0)
			$erros[] = "Este time já existe.";

		if($imagem <> 'NULL' && count($erros) == 0){
		 	$imagem = $nome_time;
			$destino = "img/jogadores/".$nome_time;
			if(!move_uploaded_file($_FILES['arquivo']['tmp_name'], $destino)){
				$erros[] = "Falha no upload do arquivo";
			}
		}

		if(count($erros) == 0){	
			$sql = "INSERT INTO equipes (usuario, nometime, imagem, id1, id2, id3, id4, id5 ) VALUES ('$usuario', '$nome_time', '$imagem', $id[0], $id[1], $id[2], $id[3], $id[4])";
			$resultado = mysqli_query($conexao, $sql);
			if($resultado){
				$mensagem = "O time <strong>$nome_time</strong> foi cadastrado com sucesso";
			}
			else{
				$mensagem = "Erro. O time não pôde ser cadastrado.";
				$mensagem .= mysqli_error($conexao); // para debug
			}
		}
	}
	
	include "includes/cabecalho.php";


	if(!(isset($_POST['cadastrar'])) || count($erros)!=0){
?>
<div class="container">
	<?php
		if(isset($erros) and count($erros) > 0){
			echo "<ul>";
			foreach ($erros as $erro) {
				echo "<li style='color:red'>$erro</li>";
			}
			echo "</ul>";
		}else if(isset($_SESSION['login'])){
			?>
			<form action="" method="post" enctype="multipart/form-data">
				<fieldset>
					<legend>Monte aqui seu time:</legend>
					<div class="form-item">
						<label for="nome_time">Nome do time:</label>
						<input type="text" name="nome_time" id="nome_time" required>
					</div>
					<div class="form-item">
						<label for="arquivo">Envie a imagem do seu time:</label>
						<input type="file" name="arquivo" id="arquivo">
					</div>
					<p>Obs: Os jogadores precisam estar cadastrados no site.</p>
					<div class="form-item">
						<label>Nickname dos jogadores:</label><br><br>
							<label for="nome_jogador1">Jogador 1:</label>
							<input type="text" name="nome_jogador1" id="nome_jogador1" size="30" required>
							<br><label for="nome_jogador1">Jogador 2:</label>
							<input type="text" name="nome_jogador2" id="nome_jogador2" size="30" required>
							<br><label for="nome_jogador1">Jogador 3:</label>
							<input type="text" name="nome_jogador3" id="nome_jogador3" size="30" required>
							<br><label for="nome_jogador1">Jogador 4:</label>
							<input type="text" name="nome_jogador4" id="nome_jogador4" size="30" required>
							<br><label for="nome_jogador1">Jogador 5:</label>
							<input type="text" name="nome_jogador5" id="nome_jogador5" size="30" required>
					</div>
					<div class="form-item">
						<input type="submit" name="cadastrar" value="Cadastrar Time!">
						<input type="reset" value="Reset">
					</div>
				</fieldset>
			</form>
			<?php
				}else{
					echo "<h2 class=''>Efetue o login para montar um time.</h2>";
				}
			?>
</div>
<?php
	}
	else{
		?>
		<h1 style='color: white'>Cadastro efetuado com sucesso!!</h1>
		<div>
			<a href="inscricoes.php">Voltar</a>
		</div>
		<?php		
	}
	include "includes/rodape.php";
?>